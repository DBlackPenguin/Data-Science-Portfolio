-- Employee Demographics Data Mart
create table employee_demographics (
	total_employees integer,
	male_employees integer,
	female_employees integer,
	age_group_20_30 integer,
	age_group_31_40 integer,
	age_group_41_50 integer,
	age_group_51_60 integer
);
with temp_table as (
	select 
	    count(*) as total_employees,
	    count(*) filter (where gender = 'Male') as male_employees,
	    count(*) filter (where gender = 'Female') as female_employees,
	    count(*) filter (where age between 20 and 30) as age_group_20_30,
	    count(*) filter (where age between 31 and 40) as age_group_31_40,
	    count(*) filter (where age between 41 and 50) as age_group_41_50,
	    count(*) filter (where age between 51 and 60) as age_group_51_60
	from data_management_payroll dmp 
)
insert into employee_demographics
select * from temp_table;

-- Applicant Demographics Data Mart
create table applicant_demographics (
	total_applicants integer,
	male_applicants integer,
	female_applicants integer,
	age_group_20_30 integer,
	age_group_31_40 integer,
	age_group_41_50 integer,
	age_group_51_60 integer,
	potential_applicants integer
);
with temp_table as (
	select
		count(*) as total_applicants,
		count(*) filter (where gender = 'Male') as male_applicants,
		count(*) filter (where gender = 'Female') as female_applicants,
		count(*) filter (where age between 20 and 30) as age_group_20_30,
		count(*) filter (where age between 31 and 40) as age_group_31_40,
		count(*) filter (where age between 41 and 50) as age_group_41_50,
		count(*) filter (where age between 51 and 60) as age_group_51_60,
		count(*) filter (where offerstatus = 'Hired') as potential_applicants
	from data_recruitment_selection drs
)
insert into applicant_demographics
select * from temp_table;

-- Human Resources Costs Data Mart
create table human_resources_costs (
	total_salary numeric,
	average_salary numeric,
	total_overtime_pay numeric,
	average_overtime_pay numeric
);
with temp_table as (
	select
		sum(salary) as total_salary,
		round(avg(salary), 2) as average_salary,
		sum(overtimepay) as total_overtime_pay,
		round(avg(overtimepay), 2) as average_overtime_pay
	from data_management_payroll dmp
)
insert into human_resources_costs
select * from temp_table;

-- Employee Performances Data Mart
create table employee_performances (
	reviewperiod varchar,
	total_evaluations integer,
	average_rating numeric,
	bad_performances integer
);
with temp_table as (
	select 
		reviewperiod,
		count(*) as total_evaluations,
		round(avg(rating), 2) as average_rating,
		count(*) filter (where "comments" = 'Needs improvement') as bad_performances
	from data_performance_management dpm
	group by reviewperiod
)
insert into employee_performances
select * from temp_table;